# Your Personal — passo a passo (login só com e-mail)

1. **Firebase** (console.firebase.google.com): criar projeto > Authentication: ativar só *E-mail/senha* > Firestore Database: criar > aba Regras: colar `firestore.rules` > Configurações do projeto: adicionar app Web e copiar as chaves para `config.js`.
2. `npm install` e `npx expo start` (teste no celular com o app Expo Go).
3. Gerar o instalável: `npm i -g eas-cli`, `eas login`, `eas init` (cole o projectId em `app.json`), depois `eas build -p android --profile preview` (gera o APK).
4. **Notificações no Android:** no Firebase, adicione um app Android com o pacote `com.pedroguilherme.yourpersonal`, baixe o `google-services.json` para a pasta do projeto, adicione `"googleServicesFile":"./google-services.json"` em `android` no `app.json` e envie a chave FCM com `eas credentials`. Faça isso antes do build do passo 3.
5. iOS: `eas build -p ios` (exige conta Apple Developer, US$ 99/ano).
