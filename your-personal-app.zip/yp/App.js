import React,{useEffect,useState} from 'react';
import {View,Text,TextInput,TouchableOpacity,ScrollView,Image,Alert,Platform,StyleSheet,SafeAreaView,StatusBar} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import {CameraView,useCameraPermissions} from 'expo-camera';
import * as Notifications from 'expo-notifications';
import Constants from 'expo-constants';
import QRCode from 'react-native-qrcode-svg';
import {onAuthStateChanged,signOut,createUserWithEmailAndPassword,signInWithEmailAndPassword,sendEmailVerification,reload} from 'firebase/auth';
import {doc,setDoc,getDoc,onSnapshot,collection,addDoc,updateDoc,deleteDoc,query,where} from 'firebase/firestore';
import {auth,db} from './firebase';

Notifications.setNotificationHandler({handleNotification:async()=>({shouldShowAlert:true,shouldPlaySound:true,shouldSetBadge:false})});
const CATS=['Camisas','Calças e bermudas','Acessórios'];
const OCC=['Vôlei','Igreja','Shopping','Cinema','Encontro','Trabalho','Festa','Academia'];
const C={ac:'#7a3cff',bg:'#faf7f2',bd:'#e7e1d9',mut:'#6f6a73'};

async function reg(uid){try{
  if(Platform.OS==='android')await Notifications.setNotificationChannelAsync('default',{name:'default',importance:Notifications.AndroidImportance.MAX});
  let {status}=await Notifications.getPermissionsAsync();
  if(status!=='granted')({status}=await Notifications.requestPermissionsAsync());
  if(status!=='granted')return;
  const t=(await Notifications.getExpoPushTokenAsync({projectId:Constants.expoConfig.extra.eas.projectId})).data;
  await setDoc(doc(db,'users',uid),{push:t},{merge:true});
}catch(e){}}
async function ping(uid,title,body){try{
  const s=await getDoc(doc(db,'users',uid));const to=s.data()&&s.data().push;
  if(to)await fetch('https://exp.host/--/api/v2/push/send',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({to,title,body,sound:'default'})});
}catch(e){}}
async function pick(set){
  const r=await ImagePicker.launchImageLibraryAsync({mediaTypes:ImagePicker.MediaTypeOptions.Images,allowsEditing:true,aspect:[1,1],quality:0.3,base64:true});
  if(!r.canceled)set('data:image/jpeg;base64,'+r.assets[0].base64);
}
function useQ(q,deps){const[d,setD]=useState([]);useEffect(()=>onSnapshot(q(),s=>setD(s.docs.map(x=>({id:x.id,...x.data()})))),deps);return d}

const B=({t,f,s})=><TouchableOpacity onPress={f} style={[S.b,s&&S.bs]}><Text style={[S.bt,s&&{color:C.ac}]}>{t}</Text></TouchableOpacity>;
const Chip=({t,on,f})=><TouchableOpacity onPress={f} style={[S.chip,on&&{backgroundColor:C.ac}]}><Text style={{color:on?'#fff':C.ac}}>{t}</Text></TouchableOpacity>;
const In=p=><TextInput placeholderTextColor="#999" {...p} style={S.in}/>;
const Pic=({p,sel,f,children})=><TouchableOpacity activeOpacity={f?0.7:1} onPress={f} style={[S.pc,!p.av&&{opacity:0.55},sel&&{borderColor:C.ac,borderWidth:3}]}>
  {p.photo?<Image source={{uri:p.photo}} style={S.im}/>:<View style={[S.im,{backgroundColor:'#f1e9ff'}]}/>}<Text style={{fontWeight:'600',marginTop:4}}>{p.name}</Text>{children}</TouchableOpacity>;
const Av=({u})=>u&&u.photo?<Image source={{uri:u.photo}} style={S.av}/>:<View style={[S.av,{backgroundColor:'#f1e9ff'}]}/>;

function Login(){
  const[em,setEm]=useState(''),[pw,setPw]=useState('');
  const up=async()=>{try{const c=await createUserWithEmailAndPassword(auth,em.trim(),pw);await sendEmailVerification(c.user)}catch(e){Alert.alert('Erro',e.message)}};
  const inn=async()=>{try{await signInWithEmailAndPassword(auth,em.trim(),pw)}catch(e){Alert.alert('Erro',e.message)}};
  return <ScrollView contentContainerStyle={S.pg}><Text style={S.logo}>Your Personal</Text><Text style={{color:C.mut,marginBottom:16}}>Seu personal stylist, onde você estiver.</Text>
    <In placeholder="E-mail" autoCapitalize="none" keyboardType="email-address" value={em} onChangeText={setEm}/>
    <In placeholder="Senha (mín. 6)" secureTextEntry value={pw} onChangeText={setPw}/>
    <B t="Entrar" f={inn}/><View style={{height:8}}/><B s t="Criar conta (enviamos um e-mail de verificação)" f={up}/></ScrollView>;
}
function Verify({u,ok}){return <View style={S.pg}><Text style={S.logo}>Confirme seu e-mail</Text>
  <Text style={{marginVertical:12}}>Enviamos um link para {u.email}. Abra o e-mail no Gmail, toque no link e volte aqui.</Text>
  <B t="Já verifiquei" f={async()=>{await reload(u);ok();if(!u.emailVerified)Alert.alert('Ainda não confirmado')}}/><View style={{height:8}}/>
  <B s t="Reenviar e-mail" f={()=>sendEmailVerification(u).then(()=>Alert.alert('Enviado'))}/><View style={{height:8}}/><B s t="Sair" f={()=>signOut(auth)}/></View>}

function Profile({me,uid,email,done}){
  const[n,setN]=useState(me.name||''),[b,setB]=useState(me.birth||''),[g,setG]=useState(me.gender||'M'),[r,setR]=useState(me.role||'user'),[ph,setPh]=useState(me.photo||'');
  const save=async()=>{if(!n.trim()||b.length<10)return Alert.alert('Preencha nome e nascimento (DD/MM/AAAA)');
    await setDoc(doc(db,'users',uid),{name:n.trim(),birth:b,gender:g,role:r,photo:ph,email,done:true},{merge:true});done()};
  return <ScrollView contentContainerStyle={S.pg}><Text style={S.h}>Seu perfil</Text>
    <TouchableOpacity onPress={()=>pick(setPh)} style={{alignItems:'center',marginBottom:10}}><Av u={{photo:ph}}/><Text style={{color:C.ac}}>Escolher foto</Text></TouchableOpacity>
    <In placeholder="Nome" value={n} onChangeText={setN}/><In placeholder="Nascimento DD/MM/AAAA" keyboardType="numbers-and-punctuation" value={b} onChangeText={setB} maxLength={10}/>
    <View style={S.row}><Chip t="Masculino" on={g==='M'} f={()=>setG('M')}/><Chip t="Feminino" on={g==='F'} f={()=>setG('F')}/></View>
    <View style={S.row}><Chip t="Sou usuário" on={r==='user'} f={()=>setR('user')}/><Chip t="Sou personal" on={r==='personal'} f={()=>setR('personal')}/></View>
    <B t="Salvar" f={save}/>{me.done?<><View style={{height:8}}/><B s t="Sair da conta" f={()=>signOut(auth)}/></>:null}</ScrollView>;
}
function Closet({uid}){
  const[cat,setCat]=useState(CATS[0]),[nm,setNm]=useState(''),[ph,setPh]=useState('');
  const ps=useQ(()=>collection(db,'users',uid,'pieces'),[uid]).filter(p=>p.cat===cat);
  const add=async()=>{if(!nm.trim())return Alert.alert('Dê um nome à peça');
    await addDoc(collection(db,'users',uid,'pieces'),{name:nm.trim(),cat,photo:ph,av:true});setNm('');setPh('')};
  return <><Text style={S.h}>Guarda-roupa</Text><View style={S.row}>{CATS.map(c=><Chip key={c} t={c} on={c===cat} f={()=>setCat(c)}/>)}</View>
    <View style={S.grid}>{ps.map(p=><Pic key={p.id} p={p}><Text style={{color:p.av?'#1f9d55':'#d64545',fontWeight:'700'}}>{p.av?'Disponível':'Indisponível'}</Text>
      <B s t={p.av?'Marcar suja':'Liberar'} f={()=>updateDoc(doc(db,'users',uid,'pieces',p.id),{av:!p.av})}/>
      <B s t="Remover" f={()=>Alert.alert('Remover peça?','',[{text:'Não'},{text:'Sim',onPress:()=>deleteDoc(doc(db,'users',uid,'pieces',p.id))}])}/></Pic>)}</View>
    <Text style={S.h}>Adicionar em "{cat}"</Text><B s t={ph?'Trocar foto':'Escolher foto'} f={()=>pick(setPh)}/>{ph?<Image source={{uri:ph}} style={S.av}/>:null}
    <In placeholder="Nome da peça (ex.: Bermuda jeans)" value={nm} onChangeText={setNm}/><B t="Salvar peça" f={add}/></>;
}
function Occ({me}){
  const[o,setO]=useState(''),[t,setT]=useState(''),[d,setD]=useState(new Date().toLocaleDateString('pt-BR').slice(0,5)),[h,setH]=useState('19:00');
  const send=async()=>{const pl=o||t.trim();
    if(!me.pid)return Alert.alert('Conecte-se a um personal','Vá em Meu ID e escaneie o QR dele.');
    if(!pl)return Alert.alert('Escolha ou digite a ocasião');
    await addDoc(collection(db,'requests'),{uid:me.id,uname:me.name,pid:me.pid,place:pl,date:d,time:h,status:'pending',sug:[],note:'',at:Date.now()});
    ping(me.pid,'Novo pedido de look',me.name+' vai: '+pl+' ('+d+' '+h+'). Sugira uma peça!');setO('');setT('');Alert.alert('Pedido enviado!')};
  return <><Text style={S.h}>Qual a ocasião de hoje?</Text><View style={S.row}>{OCC.map(c=><Chip key={c} t={c} on={c===o} f={()=>setO(c===o?'':c)}/>)}</View>
    <In placeholder="Ou digite onde você vai" value={t} onChangeText={setT}/><View style={{flexDirection:'row',gap:8}}>
    <TextInput style={[S.in,{flex:1}]} value={d} onChangeText={setD} placeholder="Dia DD/MM"/><TextInput style={[S.in,{flex:1}]} value={h} onChangeText={setH} placeholder="Hora"/></View>
    <B t="Pedir sugestão ao personal" f={send}/></>;
}
function PReq({r,close}){
  const ps=useQ(()=>collection(db,'users',r.uid,'pieces'),[r.id]).filter(p=>p.av);
  const[sel,setSel]=useState([]),[nt,setNt]=useState('');
  const tg=id=>setSel(s=>s.includes(id)?s.filter(x=>x!==id):[...s,id]);
  const send=async()=>{if(!sel.length)return Alert.alert('Selecione ao menos uma peça');
    await updateDoc(doc(db,'requests',r.id),{sug:sel,note:nt.trim(),status:'done'});
    ping(r.uid,'Seu personal respondeu!','Veja a sugestão para: '+r.place);close()};
  return <><B s t="← Voltar" f={close}/><Text style={S.h}>{r.uname} vai: {r.place}</Text><Text style={{color:C.mut}}>{r.date} {r.time}</Text>
    <Text style={S.h}>Peças disponíveis</Text>{CATS.map(k=>{const q=ps.filter(p=>p.cat===k);return q.length?<View key={k}><Text style={{color:C.mut}}>{k}</Text><View style={S.grid}>{q.map(p=><Pic key={p.id} p={p} sel={sel.includes(p.id)} f={()=>tg(p.id)}/>)}</View></View>:null})}
    {!ps.length?<Text>O cliente não tem peças disponíveis.</Text>:null}<In placeholder="Dica extra (opcional)" value={nt} onChangeText={setNt}/><B t={'Enviar sugestão ('+sel.length+')'} f={send}/></>;
}
function Reqs({me,isP}){
  const R=useQ(()=>query(collection(db,'requests'),where(isP?'pid':'uid','==',me.id)),[me.id]).sort((a,b)=>b.at-a.at);
  const mine=useQ(()=>collection(db,'users',me.id,'pieces'),[me.id]);const[open,setOpen]=useState(null);
  if(open)return <PReq r={open} close={()=>setOpen(null)}/>;
  return <><Text style={S.h}>{isP?'Pedidos':'Sugestões'}</Text>{R.map(r=><View key={r.id} style={S.card}><Text style={{fontWeight:'700'}}>{isP?r.uname+' vai: '+r.place:r.place}</Text>
    <Text style={{color:C.mut}}>{r.date} {r.time} · {r.status==='pending'?'⏳ aguardando':'✅ respondido'}</Text>
    {!isP&&r.status==='done'?<View style={S.grid}>{r.sug.map(id=>mine.find(p=>p.id===id)).filter(Boolean).map(p=><Pic key={p.id} p={p}/>)}</View>:null}
    {!isP&&r.note?<Text>💬 {r.note}</Text>:null}{isP&&r.status==='pending'?<B t="Ver peças e sugerir" f={()=>setOpen(r)}/>:null}</View>)}
    {!R.length?<Text style={{color:C.mut}}>Nada por aqui ainda.</Text>:null}</>;
}
function Clients({me}){const L=useQ(()=>query(collection(db,'users'),where('pid','==',me.id)),[me.id]);
  return <><Text style={S.h}>Clientes</Text>{L.map(c=><View key={c.id} style={[S.card,S.row]}><Av u={c}/><Text style={{fontWeight:'700'}}>{c.name}</Text></View>)}{!L.length?<Text style={{color:C.mut}}>Nenhum cliente conectado.</Text>:null}</>}
function IdTab({me,isP}){
  const[scan,setScan]=useState(false),[perm,ask]=useCameraPermissions(),[p,setP]=useState(null);
  useEffect(()=>{if(me.pid)getDoc(doc(db,'users',me.pid)).then(s=>setP(s.data()))},[me.pid]);
  const got=async({data})=>{setScan(false);const s=await getDoc(doc(db,'users',data));
    if(!s.exists()||s.data().role!=='personal')return Alert.alert('QR inválido','Esse QR não é de um personal.');
    await updateDoc(doc(db,'users',me.id),{pid:data});Alert.alert('Conectado a '+s.data().name)};
  return <><Text style={S.h}>Meu ID</Text><View style={{alignItems:'center',backgroundColor:'#fff',padding:16,borderRadius:16}}><QRCode value={me.id} size={180}/></View>
    <Text selectable style={{textAlign:'center',marginVertical:8,color:C.mut}}>{me.id}</Text>
    {isP?<Text style={{textAlign:'center'}}>Mostre este QR aos seus clientes.</Text>:me.pid&&p?<View style={[S.card,S.row]}><Av u={p}/><Text>Seu personal: <Text style={{fontWeight:'700'}}>{p.name}</Text></Text></View>:null}
    {!isP&&!scan?<B t={me.pid?'Trocar de personal (ler QR)':'Ler QR do meu personal'} f={async()=>{if(!perm||!perm.granted){const r=await ask();if(!r.granted)return}setScan(true)}}/>:null}
    {scan?<View><CameraView style={{height:300,borderRadius:16,overflow:'hidden'}} barcodeScannerSettings={{barcodeTypes:['qr']}} onBarcodeScanned={got}/><B s t="Cancelar" f={()=>setScan(false)}/></View>:null}</>;
}
function Main({user}){
  const[me,setMe]=useState(undefined),[tab,setTab]=useState('');
  useEffect(()=>onSnapshot(doc(db,'users',user.uid),s=>setMe(s.exists()?{id:s.id,...s.data()}:{id:s.id})),[]);
  useEffect(()=>{reg(user.uid)},[]);
  if(!me)return null;
  if(!me.done||tab==='me')return <Profile me={me} uid={user.uid} email={user.email} done={()=>setTab('')}/>;
  const isP=me.role==='personal',tabs=isP?[['req','📩 Pedidos'],['cli','👥 Clientes'],['id','🔳 ID'],['me','👤 Perfil']]:[['closet','👕 Roupas'],['occ','📍 Ocasião'],['req','💬 Sugestões'],['id','🔳 ID'],['me','👤 Perfil']];
  const t=tab||tabs[0][0];
  return <View style={{flex:1}}><ScrollView contentContainerStyle={S.pg}>{t==='closet'?<Closet uid={me.id}/>:t==='occ'?<Occ me={me}/>:t==='req'?<Reqs me={me} isP={isP}/>:t==='cli'?<Clients me={me}/>:<IdTab me={me} isP={isP}/>}</ScrollView>
    <View style={S.nav}>{tabs.map(([k,l])=><TouchableOpacity key={k} style={{flex:1,padding:14}} onPress={()=>setTab(k)}><Text style={{textAlign:'center',fontSize:11,color:t===k?C.ac:C.mut}}>{l}</Text></TouchableOpacity>)}</View></View>;
}
export default function App(){
  const[u,setU]=useState(undefined),[,tick]=useState(0);
  useEffect(()=>onAuthStateChanged(auth,x=>setU(x)),[]);
  if(u===undefined)return null;
  return <SafeAreaView style={{flex:1,backgroundColor:C.bg,paddingTop:StatusBar.currentHeight||0}}>{!u?<Login/>:!u.emailVerified?<Verify u={u} ok={()=>tick(x=>x+1)}/>:<Main user={u}/>}</SafeAreaView>;
}
const S=StyleSheet.create({pg:{padding:16,paddingBottom:40},logo:{fontSize:30,fontWeight:'800',color:C.ac},h:{fontSize:20,fontWeight:'700',marginVertical:10},
 b:{backgroundColor:C.ac,padding:13,borderRadius:12,alignItems:'center',marginVertical:4},bs:{backgroundColor:'#f1e9ff'},bt:{color:'#fff',fontWeight:'600'},
 in:{borderWidth:1,borderColor:C.bd,backgroundColor:'#fff',borderRadius:12,padding:12,marginVertical:5,fontSize:16},
 chip:{paddingVertical:8,paddingHorizontal:14,borderRadius:99,backgroundColor:'#f1e9ff'},row:{flexDirection:'row',flexWrap:'wrap',gap:8,alignItems:'center',marginVertical:6},
 grid:{flexDirection:'row',flexWrap:'wrap',gap:10},pc:{width:'47%',backgroundColor:'#fff',borderRadius:14,padding:8,borderWidth:1,borderColor:C.bd},im:{width:'100%',aspectRatio:1,borderRadius:10},
 av:{width:56,height:56,borderRadius:28,marginVertical:6},card:{backgroundColor:'#fff',borderRadius:16,padding:14,marginVertical:8,borderWidth:1,borderColor:C.bd},
 nav:{flexDirection:'row',borderTopWidth:1,borderColor:C.bd,backgroundColor:'#fff'}});
